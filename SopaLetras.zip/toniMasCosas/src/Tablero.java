import java.util.Arrays;



// 1- Bucle de palabras. * Terminado
// 2- Por cada palabra recorrer las letras.
// 3- Poner cada letra en una fila distinta del tablero.
// 4- Igual que el 3 pero filas aleatorias.
// 5- igual que el 4 pero la posición de la columna es aleatoria.

public class Tablero {

    private final int ROW_LENGTH = 10;
    private final int COL_LENGTH = 10;
    private Letra [][] letras;
    private Letra []myLetra;

    private Palabra [] palabras;


    public Tablero () {

        this.letras = new Letra[ ROW_LENGTH ][ COL_LENGTH ];
        this.palabras = new Palabra [] {
            new Palabra("ESCOLA"),
                    new Palabra("AULA"),
                    new Palabra("BIBLIOTECA"),
                    new Palabra("FUTUR"),
                    new Palabra("ESTUDIS"),
        };
    }

    
    public Palabra [] recorrerPalabras () {

        Palabra [] myLista = new Palabra[palabras.length];

        for (int i = 0; i < palabras.length; i++) {

            myLista[i] = palabras[i];


        }
        return myLista;

    }


    public void recorrerLetrasPorPalabra () {



        for (int i = 0; i < palabras.length; i++) {

            for (int j = 0; j < palabras[i].getLetras().length; j++) {



            }

        }

    }




    private void ordenarPalabras () {

        for ( int i = 0; i < this.palabras.length; i++) {
            for ( int j = 0; j < this.palabras.length; j++ ) {

                if ( this.palabras[i].getLetras().length < this.palabras[j].getLetras().length) {
                    Palabra aux = this.palabras[i];
                    this.palabras[i] = this.palabras[j];
                    this.palabras[j] = aux;

                }

            }

        }

    }


    public boolean sePuedeInsertar ( Palabra palabra ) {
        return true;
    }

    /*
    public String [] ordenarArray ( ) {

        String temp = "";

        for (int i = 0; i < listaPalabras.length; i++) {

            for (int j = 0; j < listaPalabras.length; j++) {

                if ( listaPalabras[i].length() > listaPalabras[j].length() ) {

                    temp = listaPalabras[i];

                    listaPalabras[i] = listaPalabras[j];

                    listaPalabras[j] = temp;

                }

            }

        }
    return listaPalabras;

    }
    */




}
