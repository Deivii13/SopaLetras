public class Letra {
    private char letra;

    public Letra(char letra) {
        this.letra = letra;
    }
}
