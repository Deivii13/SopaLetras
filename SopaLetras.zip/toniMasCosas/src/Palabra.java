public class Palabra {

    private Letra [] letras;

    public Palabra ( Letra [] letras ) {
        this.letras = letras;
    }


    public Palabra ( String palabra ) {

         this.letras = new Letra[ palabra.length() ]; // Lista de objetos

        for (int i = 0; i < palabra.length(); i++) {

            this.letras[i] = new Letra( palabra.charAt(i) );

        }


    }

    public Letra[] getLetras() {
        return letras;
    }

}
