public class SopaDeLetras {
    public static void main(String[] args) {

        // String [] listaPalabras = {"escola", "aula", "biblioteca", "estudis", "futur"};


        Tablero myTablero = new Tablero();
        //myTablero.recorrerPalabras();

        myTablero.recorrerLetrasPorPalabra();

    }



}